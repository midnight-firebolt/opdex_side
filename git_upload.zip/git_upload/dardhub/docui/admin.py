from django.contrib import admin
from .models import Appointment , MedicineSchedule
# Register your models here.
admin.site.register(Appointment)
admin.site.register(MedicineSchedule)
